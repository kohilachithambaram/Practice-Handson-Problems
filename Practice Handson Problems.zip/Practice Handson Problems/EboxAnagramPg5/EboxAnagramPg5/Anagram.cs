﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EboxAnagramPg5
{
    class Anagram
    {
        public bool checkAnagram(string firstString , string secondString)
        {
            if (firstString.Length != secondString.Length)
                return false;
            char[] firstArray = firstString.ToLower().ToCharArray();
            char[] secondArray = secondString.ToLower().ToCharArray();

            Array.Sort(firstArray);
            Array.Sort(secondArray);
            for(int i = 0; i < firstArray.Length; i++)
            {
                if (firstArray[i] != secondArray[i])
                    return false;
            }
            return true;
        }
    }
}
