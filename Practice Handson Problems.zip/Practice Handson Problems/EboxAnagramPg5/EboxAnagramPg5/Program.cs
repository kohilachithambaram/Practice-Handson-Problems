﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EboxAnagramPg5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the first string");
            string firstString = Console.ReadLine();
            Console.WriteLine("Enter the second string");
            string secondString = Console.ReadLine();
            Anagram anagram = new Anagram();
            bool isAnagram =  anagram.checkAnagram(firstString,secondString);
            if (isAnagram == true)
                Console.WriteLine("Anagram");
            else
                Console.WriteLine("Not an Anagram");
        }
    }
}
