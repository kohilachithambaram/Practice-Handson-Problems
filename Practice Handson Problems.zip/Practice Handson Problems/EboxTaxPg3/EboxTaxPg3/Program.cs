﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EboxTaxPg3
{
    class Program
    {
        static void Main(string[] args)
        {
            TaxCalulator taxCalculator = new TaxCalulator();
            string choice;
            Console.WriteLine("Greetings from Tax calculator.\nIs Salary the ONLY source of Income?(Y/N)");
            choice = Console.ReadLine();
            if(choice.Equals("Y",StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Enter the Salary amount ");
                float salaryAmount = float.Parse(Console.ReadLine());
                Console.WriteLine("Your Tax Amount is " + taxCalculator.MyTaxAmount(salaryAmount) + " INR");
            }
            else if(choice.Equals("N", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Enter the Salary amount ");
                float salaryAmount = float.Parse(Console.ReadLine());
                Console.WriteLine("Enter the Income from Other Source ");
                float otherSourceAmount = float.Parse(Console.ReadLine());
                Console.WriteLine("Your Tax Amount is " + taxCalculator.MyTaxAmount(salaryAmount, otherSourceAmount) + " INR");
            }
        }
    }
}
