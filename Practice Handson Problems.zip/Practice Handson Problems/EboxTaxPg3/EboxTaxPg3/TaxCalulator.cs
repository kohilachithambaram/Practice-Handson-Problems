﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EboxTaxPg3
{
    class TaxCalulator
    {
        public float MyTaxAmount(float salary)
        {
            float taxAmount = (30 * salary) / 100;
            return taxAmount;
        }

        public float MyTaxAmount(float salary,float incomeFromOtherSource)
        {
            float taxAmount = ((30 * salary) / 100 )+ ((10 * incomeFromOtherSource) / 100);
            return taxAmount;
        }
    }
}
