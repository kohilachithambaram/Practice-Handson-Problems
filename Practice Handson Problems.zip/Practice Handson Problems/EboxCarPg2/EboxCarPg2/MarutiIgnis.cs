﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EboxCarPg2
{
    class MarutiIgnis : CarFeatures, IMusicFeatures
    {
        public void PlayMusic()
        {
            Console.WriteLine("Uses JBL music player");
        }
        public void IgnisFearures()
        {
            Driving();
            PlayMusic();
        }
    }
}
