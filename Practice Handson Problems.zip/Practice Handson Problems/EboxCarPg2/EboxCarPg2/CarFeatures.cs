﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EboxCarPg2
{
    public abstract class CarFeatures
    {
        public void Driving()
        {
            Console.WriteLine("This car has 4 wheels and a steering to drive");
        }
    }
}
