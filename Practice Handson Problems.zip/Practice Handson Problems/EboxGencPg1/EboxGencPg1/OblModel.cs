﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EboxGencPg1
{
    public class OblModel : TrainingModel
    {
        int workingDays = 45;
        public override void TrainingDuration(string modelName, int enablementDurationDayInDays)
        {
            enablementDurationDayInDays += workingDays;
            Console.WriteLine("Model Name: " + modelName + " , Training Duration: " + enablementDurationDayInDays);
        }
    }
}
