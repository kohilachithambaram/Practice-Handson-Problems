﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EboxGencPg1
{
    class Program
    {
        static void Main(string[] args)
        {
            ParcModel parcModel = new ParcModel();
            parcModel.TrainingDuration("PARC",10);

            OblModel oblModel = new OblModel();
            oblModel.TrainingDuration("OBL",15);
        }
    }
}
